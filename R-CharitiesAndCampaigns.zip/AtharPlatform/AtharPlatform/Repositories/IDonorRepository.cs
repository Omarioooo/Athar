﻿namespace AtharPlatform.Repositories
{
    public interface IDonorRepository : IRepository<Donor>
    {
    }
}
