﻿namespace AtharPlatform.Models.Enums
{
    public enum CharityStatusEnum
    {
        Pending = 1,
        Approved = 2,
        Rejected = 3
    }
}
