﻿namespace AtharPlatform.Models.Enum
{
    public enum CampaignCategoryEnum
    {
        Education = 0,
        Health = 1,
        Orphans = 2,
        Food = 3,
        Shelter = 4,
        Other = 99
    }
}
