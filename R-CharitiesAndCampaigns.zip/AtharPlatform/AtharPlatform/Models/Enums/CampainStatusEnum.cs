﻿namespace AtharPlatform.Models.Enum
{
    public enum CampainStatusEnum
    {
        inProgress = 1,
        Completed,
        expired
    }
}
